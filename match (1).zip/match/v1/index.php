<?php

error_reporting(-1);
ini_set('display_errors', 'On');

require_once '../include/db_handler.php';
require '.././libs/Slim/Slim.php';

\Slim\Slim::registerAutoloader();

$app = new \Slim\Slim();

	/* * *
	 * API  search 
	 */
	$app->post('/getlistuser', function() use ($app) {
		// check for required params
		$page = (isset($_GET['page']) && $_GET['page'] > 0) ? $_GET['page'] : 1;
		$currentPage=$page;
		$limit = isset($_GET['limit']) ? $_GET['limit'] : 20;
		$offset = (--$page) * $limit;
		$db = new DbHandler();
		// reading post params
		verifyRequiredParams(array('UserID'));
		$userID = $app->request->post('UserID') ;
		$homeTown = (isset($_POST['HomeTown']) && !empty($_POST['HomeTown']) > 0) ? $app->request->post('HomeTown') : 0;
		$toHeight = (isset($_POST['ToHeight']) && !empty($_POST['ToHeight']) > 0) ? $app->request->post('ToHeight') : 3000;
		$fromHeight = (isset($_POST['FromHeight']) && !empty($_POST['FromHeight']) > 0) ? $app->request->post('FromHeight') : 0;
		$fromWeight = (isset($_POST['FromWeight']) && !empty($_POST['FromWeight']) > 0) ? $app->request->post('FromWeight') : 0;
		$toWeight = (isset($_POST['ToWeight']) && !empty($_POST['ToWeight']) > 0) ? $app->request->post('ToWeight') : 200;
		$toYearOld = (isset($_POST['ToYearOld']) && !empty($_POST['ToYearOld']) > 0) ? $app->request->post('ToYearOld') : 200;
		$fromYearOld = (isset($_POST['FromYearOld']) && !empty($_POST['FromYearOld']) > 0) ? $app->request->post('FromYearOld') : 0;
		$isShow = (isset($_POST['IsShow']) && !empty($_POST['IsShow']) > 0) ? $app->request->post('IsShow') : 0;
		$isImage = (isset($_POST['IsImage']) && !empty($_POST['IsImage']) > 0) ? $app->request->post('IsImage') : 0;
		$users = $db->listUsersAfterSearch($userID,$limit,$offset,$currentPage,$isImage,$isShow,$fromYearOld,$toYearOld,$homeTown,$fromHeight,$toHeight,$toWeight,$fromWeight);
		if(!is_null($users)){
			$response["common"]["status"] = 0;
			$response["common"]["msg"] = "";
			$response["data"] = array();
			$response["data"] =$users;
		}else{
			$response["common"]["status"] = 2;
			$response["common"]["msg"] = "DB Error";
		}
		// echo json response
		echoRespnse(200, $response);
	});
	
	
	/* * *
	 * API  send like
	 */
	$app->post('/sendlike', function() use ($app) {
		// check for required params
	
		$db = new DbHandler();
		verifyRequiredParams(array('AccessToken', 'MyUserID', 'OtherUserID'));
		// reading post params
		$myUserID = $app->request->post('MyUserID');
		$accessToken = $app->request->post('AccessToken');
		$otherUserID = $app->request->post('OtherUserID');
		$myLike = $app->request->post('MyLike');
		$mySpecialLike = $app->request->post('MySpecialLike');
		$response = $db->insertSendLike($myUserID,$accessToken,$otherUserID,$myLike,$mySpecialLike);
		// echo json response
		echoRespnse(200, $response);
	});
	
	
	
	/* * *
	 * API Get detail data User
	 */
	$app->put('/getdetailuser', function() use ($app) {
	    global $app;
	    $db = new DbHandler();
	    $user=array();
	    verifyRequiredParams(array('AccessToken', 'MyUserID','OtherUserID'));
	    $accessToken = $app->request->put('AccessToken');
	    $myUserID = $app->request->put('MyUserID');
	    $otherUserID = $app->request->put('OtherUserID');
	    $user = $db->getDetailUser($accessToken,$myUserID,$otherUserID); 
	    $imageLists=$db->getListImageUser($otherUserID);  
	    $response["common"]["error"] = 0;
	    $response["common"]["msg"] = "";
	    $response["data"] = array();
	    $response["data"] =$user;
	    $response["data"]["ImageList"]=$imageLists;
	    echoRespnse(200, $response);
	});

	/* * *
	* API Insert user photo
	*/
	$app->post('/insertuserphoto', function() use ($app) { 
		$params = $app->request->post();
		// check for required params
		$options=$app->request->post('Options');  
		if($options!=2){
			verifyRequiredParams(array('AccessToken', 'UserID', 'Options','ImageUser'));
		}else{ 
			verifyRequiredParams(array('AccessToken', 'UserID', 'Options'));
		}
		// reading post params
		$accessToken = $app->request->post('AccessToken');
		$userID = $app->request->post('UserID');
		$imageSize = $app->request->post('ImageSize');
		$height = $app->request->post('Height');
		$width = $app->request->post('Width'); 
		$pathImage=$app->request->post('ImageUser');
// 		upload file
		if($options==2){
			if (!isset($_FILES['ImageUser'])) {
				echo "No files uploaded!!";
				return;
			}
			$target="upload/";
			$tmpname = $_FILES['ImageUser']['tmp_name'];
			if (!is_dir($target)) {
				mkdir($target, 777);
				chmod($target, 777);
			}
			
			$imageUser=  $target.time().$_FILES['ImageUser']['name'];
			move_uploaded_file($tmpname,$imageUser);
		}elseif($options==1){
			$imageUser=$pathImage;
		}else{
			$imageUser="";
		}	
		//insert DB
		$db = new DbHandler();	
		$response = $db->insertPhoto($accessToken,$userID,$options,$imageSize,$height,$width,$imageUser);
		// echo json response
		echoRespnse(200, $response);
	});
	
	//Successfull.
		
	/* * *
	 * API  update violation for user
	 */
	$app->put('/violation', function() use ($app) {
		global $app;
		$violation=1;
		verifyRequiredParams(array('AccessToken', 'MyUserID','Violation','OtherUserID'));
		$accessToken = $app->request->put('AccessToken');
		$myUserID = $app->request->put('MyUserID');
		$violation = $app->request->put('Violation');
		$otherUserID = $app->request->put('OtherUserID');
		$content = $app->request->put('Content');
		$db = new DbHandler();
		$response = $db->updateViolation($myUserID,$accessToken,$otherUserID,$violation,$content);
		echoRespnse(200, $response);
		});
		
	/* * *
	 * API  Get change password for user
	 */
	$app->put('/changepush', function() use ($app) {
		global $app;
		verifyRequiredParams(array('AccessToken', 'UserID','PushStatus'));
		$accessToken = $app->request->put('AccessToken');
		$userID = $app->request->put('UserID');
		$pushStatus = $app->request->put('PushStatus');
		$db = new DbHandler();
		$response = $db->updateChangePush($userID,$accessToken,$pushStatus);
		echoRespnse(200, $response);
	});
		
	/* * *
	 * API  Get change password for user
	 */
	$app->put('/changepassword', function() use ($app) {
		global $app;
		verifyRequiredParams(array('AccessToken', 'UserID','NewPassword'));
		$accessToken = $app->request->put('AccessToken');
		$userID = $app->request->put('UserID');
		$newPassword = $app->request->put('NewPassword');
		$db = new DbHandler();
		$response = $db->updateChangePassword($userID,$accessToken,$newPassword);
		echoRespnse(200, $response);
	});
		
	/* * *
	 * API  Get current password for user
	 */
	$app->put('/getpassword', function() use ($app) {
		global $app;
		verifyRequiredParams(array('AccessToken', 'UserID'));
		$accessToken = $app->request->put('AccessToken');
		$userID = $app->request->put('UserID');
		$db = new DbHandler();
		$response = $db->getCurrentPassword($userID,$accessToken);
		echoRespnse(200, $response);
		});
	
	/* * *
	 * API  Get current password for user
	 */
	$app->get('/getlistvisitor/:userid', function($userid) {
		global $app; 
		$page = (isset($_GET['page']) && $_GET['page'] > 0) ? $_GET['page'] : 1;
		$currentPage=$page;
		$limit = isset($_GET['limit']) ? $_GET['limit'] : 2;
		$offset = (--$page) * $limit;
		$db = new DbHandler();   
		$users = $db->getListVisitor($userid,$limit,$offset,$currentPage);
		$response["common"]["status"] = 0;
		$response["common"]["msg"] = "";
		$response["data"] = array();
		$response["data"] =$users;
		echoRespnse(200, $response);
	});
		
	/* * *
	* API  Get a list of user information liked for you - Others Liked for me
	 */
	$app->get('/getlistuserliked/:userid', function($userid) {
		global $app;
		$db = new DbHandler();
		$resource="getlistuserliked/";
		$user=array();
		$page = (isset($_GET['page']) && $_GET['page'] > 0) ? $_GET['page'] : 1;
		$currentPage=$page;
		$limit = isset($_GET['limit']) ? $_GET['limit'] : 2;
		$offset = (--$page) * $limit;
		$user = $db->getListUserMatched($userid,OTHERLIKED,$limit,$offset,$currentPage,$resource);
		$response["common"]["status"] = 0;
		$response["common"]["msg"] = "";
		$response["data"] = array();
		$response["data"] =$user;
		echoRespnse(200, $response);
		});
			
	/* * *
	 * API  Get a list of people information you sent to them - I Liked    
	 */
	$app->get('/getlistuseryousent/:userid', function($userid) {
		global $app;
		$db = new DbHandler();
		$resource="getlistuseryousent/";
		$user=array();
		$page = (isset($_GET['page']) && $_GET['page'] > 0) ? $_GET['page'] : 1;
		$currentPage=$page;
		$limit = isset($_GET['limit']) ? $_GET['limit'] : 2;
		$offset = (--$page) * $limit;
		$user = $db->getListUserMatched($userid,ILIKED,$limit,$offset,$currentPage,$resource);
		$response["common"]["status"] = 0;
		$response["common"]["msg"] = "";
		$response["data"] = array();
		$response["data"] =$user;
		echoRespnse(200, $response);
	});
	
	/* * *
	* API  Get a list of user information was matched
	*/
	$app->get('/getlistusermatched/:userid', function($userid) {
		global $app;
		$db = new DbHandler();
		$resource="getlistusermatched/";
		$user=array();
		$page = (isset($_GET['page']) && $_GET['page'] > 0) ? $_GET['page'] : 1;
		$currentPage=$page;
		$limit = isset($_GET['limit']) ? $_GET['limit'] : 2;
		$offset = (--$page) * $limit;
		$user = $db->getListUserMatched($userid,MATCHED,$limit,$offset,$currentPage,$resource);
		$response["common"]["status"] = 0;
		$response["common"]["msg"] = "";
		$response["data"] = array();
		$response["data"] =$user;
		echoRespnse(200, $response);
		});	
	
	/* * *
	* API Update user profile
	*/
	$app->put('/updateuserprofile', function() use ($app) {
			global $app;
			verifyRequiredParams(array('AccessToken', 'UserID', 'UserName', 'FirstName', 'LastName', 'Gender','Email','BirthDay','ChangedDate','HavingChildren'));
			$accessToken = $app->request->put('AccessToken');
			$userID = $app->request->put('UserID');
			$userName = $app->request->put('UserName');
			$firstName = $app->request->put('FirstName');
			$lastName = $app->request->put('LastName');
			$gender = $app->request->put('Gender');
			$email = $app->request->put('Email');
			$birthDay = $app->request->put('BirthDay');
			$changedDate = $app->request->put('ChangedDate');
			$height = $app->request->put('Height');
			$weight = $app->request->put('Weight');
			$skills = $app->request->put('Skills');
			$hobby = $app->request->put('Hobby');
			$address = $app->request->put('Address');
			$homeTown = $app->request->put('HomeTown');
			$language = $app->request->put('Language');
			$bloodType = $app->request->put('BloodType');
			$job = $app->request->put('Job');
			$income = $app->request->put('Income');
			$literacy = $app->request->put('Literacy');
			$genitive = $app->request->put('Genitive');
			$extrovert = $app->request->put('Extrovert');
			$attraction = $app->request->put('Attraction');
			$drinking = $app->request->put('Drinking');
			$smoking = $app->request->put('Smoking');
			$siblings = $app->request->put('Siblings');
			$whoLivesWith = $app->request->put('WhoLivesWith');
			$holiday = $app->request->put('Holiday');
			$whenMarriage = $app->request->put('WhenMarriage');
			$requirement = $app->request->put('Requirement');
			$maritalStatus = $app->request->put('MaritalStatus');
			$havingChildren = $app->request->put('HavingChildren');
			$criteriaConsidered = $app->request->put('CriteriaConsidered');
			$wantAppointments = $app->request->put('WantAppointments');
			$costForFirstAppointments = $app->request->put('CostForFirstAppointments');
			$other = $app->request->put('Other');
			$db = new DbHandler();
			$response = $db->updateUserProfile($userID,$accessToken,$userName,$firstName,$lastName,$gender,$email
											,$birthDay,$changedDate,$height,$weight,$skills,$hobby,$address
											,$homeTown,$language,$bloodType,$job,$income,$literacy,$genitive
											,$extrovert,$attraction,$drinking,$smoking,$siblings,$whoLivesWith
											,$holiday,$whenMarriage,$requirement,$maritalStatus,$havingChildren
											,$criteriaConsidered,$wantAppointments,$costForFirstAppointments,$other);
			echoRespnse(200, $response);
		});
	
	/* * *
	 * API User logout
	 */
	$app->put('/logout', function() use ($app) {
		global $app;
		verifyRequiredParams(array('FacebookID'));
		$accessToken = $app->request->put('AccessToken');
		$facebookID=$app->request->put('FacebookID');
		$db = new DbHandler(); 
		$response = $db->updateUsers($facebookID,$accessToken);
		echoRespnse(200, $response);
	});

	/* * *
	 * API User login
	 */
	$app->post('/login', function() use ($app) {
		// check for required params
		$email = $app->request->post('Email');
		$db = new DbHandler();
		verifyRequiredParams(array('AccessToken', 'UserName', 'FirstName', 'LastName', 'BirthDay', 'FcmRegisteredID', 'Email', 'Gender','FacebookID'));
		// reading post params
		$accessToken = $app->request->post('AccessToken');
		$userName = $app->request->post('UserName');
		$firstName = $app->request->post('FirstName');
		$lastName = $app->request->post('LastName');
		$birthDay = $app->request->post('BirthDay');
		$fcmRegisteredID = $app->request->post('FcmRegisteredID');
		$gender = $app->request->post('Gender');
		$facebookID = $app->request->post('FacebookID'); 
		// validating email address
		validateEmail($email);
		$response = $db->insertUser($accessToken,$email,$userName,$firstName,$lastName,$birthDay,$fcmRegisteredID,$gender,$facebookID);
		// echo json response
		echoRespnse(200, $response);
	});
	
	/* * *
	 * user leave app
	 *  we use this url to update user's gcm registration id
	 */
	$app->put('/leaveapp', function() use ($app) { 
	    global $app;
	    verifyRequiredParams(array('UserID','AccessToken','Status'));
	
	    $userID = $app->request->put('UserID'); 
	    $accessToken = $app->request->put('AccessToken');
	    $status = $app->request->put('Status'); 
	    
	    $db = new DbHandler();
	    $response = $db->updateLeaveApp($userID,$accessToken, $status);
	
	    echoRespnse(200, $response);
	});

/* * *
 * fetching all users
 */

	$app->get('/getlistuser/:page/:limit', function($page,$limit) use ($app){ 
	    $response = array();
	    $db = new DbHandler();
	    //$page = (isset($_GET['page']) && $_GET['page'] > 0) ? $_GET['page'] : 1;
	    //$limit = isset($_GET['limit']) ? $_GET['limit'] : 10;
		//var_dump($page."-".$limit);
	    $offset = (--$page) * $limit; //calculate what data you want
	    //page 1 -> 0 * 10 -> get data from row 0 (first entry) to row 9
	    //page 2 -> 1 * 10 -> get data from row 10 to row 19
	    $paramValue = $app->request()->get('page1');
	    echo "This is a GET route with $paramValue";
	    var_dump($paramValue); die;
	    //var_dump($_SERVER['QUERY_STRING']); die;
	    // fetching all user tasks
	    $result = $db->getUsers($limit,$offset);
		//var_dump($result); die;
	    $response["error"] = false;
	    $response["users"] = array();
	
	    // pushing single chat room into array
	    /*while ($user = $result->fetch_assoc()) {
	        $tmp = array();
	        $tmp["UserID"] = $user["UserID"];
	        $tmp["UserName"] = $user["UserName"];
	        $tmp["AccessToken"] = $user["AccessToken"];
	        array_push($response["users"], $result);
	    }
		*/
		array_push($response["users"], $result);
	    echoRespnse(200, $response);
	});


	$app->post('/users/push_test', function() {
	    global $app;
		
	    verifyRequiredParams(array('message', 'api_key', 'token'));
	
	    $message = $app->request->post('message');
	    $apiKey = $app->request->post('api_key');
	    $token = $app->request->post('token');
	    $image = $app->request->post('include_image');
	
	    $data = array();
	    $data['title'] = 'Google Cloud Messaging';
	    $data['message'] = $message;
	    if ($image == 'true') {
	        $data['image'] = 'http://api.androidhive.info/gcm/panda.jpg';
	    } else {
	        $data['image'] = '';
	    }
	    $data['created_at'] = date('Y-m-d G:i:s');
	
	    $fields = array(
	        'to' => $token,
	        'data' => $data,
	    );
	
	    // Set POST variables
	    $url = 'https://gcm-http.googleapis.com/gcm/send';
	
	    $headers = array(
	        'Authorization: key=' . $apiKey,
	        'Content-Type: application/json'
	    );
	    // Open connection
	    $ch = curl_init();
	
	    // Set the url, number of POST vars, POST data
	    curl_setopt($ch, CURLOPT_URL, $url);
	
	    curl_setopt($ch, CURLOPT_POST, true);
	    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
	    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	
	    // Disabling SSL Certificate support temporarly
	    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	
	    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
	
	    $response = array();
	
	    // Execute post
	    $result = curl_exec($ch);
	    if ($result === FALSE) {
	        $response['error'] = TRUE;
	        $response['message'] = 'Unable to send test push notification';
	        echoRespnse(200, $response);
	        exit;
	    }
	
	    // Close connection
	    curl_close($ch);
	
	    $response['error'] = FALSE;
	    $response['message'] = 'Test push message sent successfully!';
	
	    echoRespnse(200, $response);
	});

function uploadfile($File){

}
/**
 * Verifying required params posted or not
 */
function verifyRequiredParams($required_fields) {
    $error = false;
    $error_fields = "";
    $request_params = array();
    $request_params = $_REQUEST;
    // Handling PUT request params
    if ($_SERVER['REQUEST_METHOD'] == 'PUT') {
        $app = \Slim\Slim::getInstance();
        parse_str($app->request()->getBody(), $request_params);
    }
    foreach ($required_fields as $field) { 
        if (!isset($request_params[$field]) || strlen(trim($request_params[$field])) <= 0) {
            $error = true;
            $error_fields .= $field . ', ';
        }
    }

    if ($error) {
        // Required field(s) are missing or empty
        // echo error json and stop the app
        $response = array();
        $app = \Slim\Slim::getInstance();
        $response["common"]["error"] = 1;
        $response["common"]["message"] = 'Required field(s) ' . substr($error_fields, 0, -2) . ' is missing or empty';
        //$response["common"]["message"]="Parameter invalid";
        echoRespnse(400, $response);
        $app->stop();
    }
}

/**
 * Validating email address
 */
function validateEmail($email) {
    $app = \Slim\Slim::getInstance();
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $response["error"] = true;
        $response["message"] = 'Email address is not valid';
        echoRespnse(400, $response);
        $app->stop();
    }
}

function IsNullOrEmptyString($str) {
    return (!isset($str) || trim($str) === '');
}

/**
 * Echoing json response to client
 * @param String $status_code Http response code
 * @param Int $response Json response
 */
function echoRespnse($status_code, $response) {
    $app = \Slim\Slim::getInstance();
    // Http response code
    $app->status($status_code);

    // setting response content type to json
    $app->contentType('application/json');

    echo json_encode($response);
}

$app->run();
?>