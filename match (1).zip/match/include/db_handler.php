<?php

/**
 * Class to handle all db operations
 * This class will have CRUD methods for database tables
 *
 * @author ThanhNV
 * @link URL Tutorial link
 */
class DbHandler {

    private $conn;

    function __construct() {
        require_once dirname(__FILE__) . '/db_connect.php';
        // opening db connection
        $db = new DbConnect();
        $this->conn = $db->connect();
    }
    
    /**
     * condition search
     */
    public function listUsersAfterSearch($user_id,$limit,$offset,$page,$isImage,$isShow,$fromYearOld,$toYearOld,$homeTown,$fromHeight,$toHeight,$toWeight,$fromWeight){
    	if ($this->isUserID($user_id)) {
    			$resource="getlistuser";
		    	$strSQLCount="SELECT UserName FROM tblUsers  WHERE IsImage = ? AND BirthDay >= ? AND BirthDay <= ? AND Height >=? AND Height <= ? AND Weight >= ? AND Weight <= ? AND  HomeTown LIKE ?";
		    	$fromDaysMinus=$fromYearOld*365;
		    	$toDate = date('Y-m-d',strtotime("-$fromDaysMinus days"));
		    	$toDaysMinus=$toYearOld*365;
		    	$fromDate = date('Y-m-d',strtotime("-$toDaysMinus days"));
		    	$home="%".$homeTown."%";
		    	$stmtCount = $this->conn->prepare($strSQLCount);
		    	$stmtCount->bind_param("issiiiis",$isImage,$fromDate,$toDate,$fromHeight,$toHeight,$fromWeight,$toWeight,$home);
		    	$stmtCount->execute();
		    	$stmtCount->bind_result($userName);
		    	$totalUser=0;
		    	while ($stmtCount->fetch()) {
		    		++$totalUser;
		    	}
		    	$totalPage=ceil($totalUser/$limit); 
		    	$stmtCount->close();
		    	
		    	$strSQL="SELECT UserID,UserName,AccessToken,FirstName,LastName,Gender,Weight,Height,BirthDay,Income,Job,Other FROM tblUsers  WHERE IsImage = ? AND BirthDay >= ? AND BirthDay <= ? AND Height >=? AND Height <= ? AND Weight >= ? AND Weight <= ? AND  HomeTown LIKE ? ";
		    	$strSQL=$strSQL." LIMIT ".$limit." OFFSET ".$offset;
		    	$stmt = $this->conn->prepare($strSQL); 
		    	
		    	$stmt->bind_param("issiiiis",$isImage,$fromDate,$toDate,$fromHeight,$toHeight,$fromWeight,$toWeight,$home);
		    	
		    	if ($stmt->execute()) {
		    		$stmt->store_result();
		    		$stmt->bind_result($userID,$userName,$accessToken,$firstName,$lastName,$gender,$weight,$height,$birthday,$income,$job,$other);
		    		$userList=array();
		    		while ($stmt->fetch()) {
		    			if($user_id!=$userID){
			    			$user = array();
			    			//get first image user
			    			$stmtImage = $this->conn->prepare("SELECT ImageUser FROM tblPhotoUsers  WHERE UserID = ? ORDER BY PhotoID DESC");
			    			 
			    			if ($stmtImage === FALSE){
			    				die($this->conn->error);
			    			} else  {
			    				$stmtImage->bind_param("i",$userID);
			    				if ($stmtImage->execute()) {
			    					$stmtImage->bind_result($imageUser);
			    					$stmtImage->fetch();
			    					$user["ImageUser"]=$imageUser;
			    				}
			    			}
			    			$stmtImage->close();
			    			$matched=$this->getLikeUser($user_id,$userID);
			    			//add element to array
			    			$user["UserID"] = $userID;
			    			$user["UserName"] = $userName;
			    			$user["AccessToken"] = $accessToken;
			    			$user["FirstName"] = $firstName;
			    			$user["LastName"] = $lastName;
			    			$user["Gender"] = $gender;
			    			$user["Weight"] = $weight;
			    			$user["Height"] = $height;
			    			$user["BirthDay"] = $birthday;
			    			$user["Income"] = $income;
			    			$user["Job"] = $job;
				    		$user["MyLike"] = $matched['MyLike'];
				    		$user["MySpecialLike"] = $matched['MySpecialLike'];
			    			$user["Other"] = $other;
			    			$userLists[]=$user;
			    			$userList["UserList"]=$userLists;
		    			}
		    		}
		    		//pagination
		    		$prePage=$page-1;
		    		$nextPage=$page+1;
		    		if($page>1 && $page<$totalPage){
		    			$userList["paging"]["previousPageUrl"]=URL.$resource."?page=".$prePage;
		    			$userList["paging"]["currentPageUrl"]=URL.$resource."?page=".$page;
		    			$userList["paging"]["nextPageUrl"]=URL.$resource."?page=".$nextPage;
		    		}elseif($page<=1 && $totalPage>1){
		    			$userList["paging"]["currentPageUrl"]=URL.$resource."?page=".$page;
		    			$userList["paging"]["nextPageUrl"]=URL.$resource."?page=".$nextPage;
		    		}elseif($page>=$totalPage && $totalPage>1){
		    			$userList["paging"]["previousPageUrl"]=URL.$resource."?page=".$prePage;
		    			$userList["paging"]["currentPageUrl"]=URL.$resource."?page=".$page;
		    		}
		    	}
		    	$stmt->close();
    	}else{
    		$userList= NULL;
    	} 	
    	return $userList;	
    }
    
    /**
     * get like user 
     */
    private function getLikeUser($myUserID,$otherUserID){
    	$stmt = $this->conn->prepare("SELECT MyLike,MySpecialLike FROM tblMatched  WHERE MyUserID = ? AND OtherUserID = ?");
    	$stmt->bind_param("ii",$myUserID,$otherUserID);
    	if ($stmt->execute()) {
    		$matched=array();
    		$stmt->bind_result($myLike, $mySpecialLike);
    		$stmt->fetch();
    		$matched["MyLike"] = $myLike;
    		$matched["MySpecialLike"] = $mySpecialLike;
    		$matched["MyUserID"] = $myUserID;
    		$matched["OtherUserID"] = $otherUserID; 
    		$stmt->close();
    		return $matched;
    	}else{
    		return NULL;
    	}
    }
    
    /**
     * update violation 
     */
    public function updateViolation($myUserID,$accessToken,$otherUserID,$violation,$content){
    	$response = array();
    	if ($this->isUserAccessToken($accessToken)) {
    		$stmtUsers = $this->conn->prepare("UPDATE tblUsers SET Violation = ? WHERE UserID = ?");
    		$stmtUsers->bind_param("ii", $violation, $otherUserID);
    		$stmtViolations = $this->conn->prepare("INSERT INTO tblViolations( MyUserID, OtherUserID, Content) values( ?, ?, ?)");
			$stmtViolations->bind_param("iis", $myUserID,$otherUserID,$content);
	    	if ($stmtUsers->execute() && $stmtViolations->execute()) {
    			// User successfully updated
    			$response["common"]["status"] = 0;
    			$response["common"]["message"] = 'Successful complete';
    		} else {
    			// Failed to update user
    			$response["common"]["status"] = 2;
    			$response["common"]["message"] = "DB error";
    			$stmtUsers->error;
    			$stmtViolations->error;
    		}
    		$stmtUsers->close();
    		$stmtViolations->close();
    	}else{
    		$response["common"]["status"] = 101;
    		$response["common"]["message"] = "Login was failed";
    	}
    
    	return $response;
    }
    
    /**
     * get change push notification
     */
    public function updateChangePush($userID,$accessToken,$pushStatus){
    	$response = array();
    	if ($this->isUserAccessToken($accessToken)) {
    		$stmt = $this->conn->prepare("UPDATE tblUsers SET PushStatus = ? WHERE UserID = ?");
    		$stmt->bind_param("si", $pushStatus, $userID);
    		 
    		if ($stmt->execute()) {
    			// User successfully updated
    			$response["common"]["status"] = 0;
    			$response["common"]["message"] = 'Successful complete';
    			$response["data"]["UserID"] = $userID;
    			$response["data"]["PushStatus"] = $pushStatus;
    		} else {
    			// Failed to update user
    			$response["common"]["status"] = 2;
    			$response["common"]["message"] = "DB error";
    			$stmt->error;
    		}
    		$stmt->close();
    	}else{
    		$response["common"]["status"] = 101;
    		$response["common"]["message"] = "Login was failed";
    	}
    	 
    	return $response;
    }
    
    /**
     * get change password
     */
    public function updateChangePassword($userID,$accessToken,$newPassword){
    	$response = array();
    	if ($this->isUserAccessToken($accessToken)) {
    		$stmt = $this->conn->prepare("UPDATE tblUsers SET Password = ? WHERE UserID = ?");
    		$stmt->bind_param("si", $newPassword, $userID);
    		 
    		if ($stmt->execute()) {
    			// User successfully updated
    			$response["common"]["status"] = 0;
    			$response["common"]["message"] = 'Successful complete';
    			$response["data"]["UserID"] = $userID;
    			$response["data"]["NewPassword"] = $newPassword;
    		} else {
    			// Failed to update user
    			$response["common"]["status"] = 2;
    			$response["common"]["message"] = "DB error";
    			$stmt->error;
    		}
    		$stmt->close();
    	}else{
    		$response["common"]["status"] = 101;
    		$response["common"]["message"] = "Login was failed";
    	}
    	
    	return $response;
    }
    
    /**
     * get cunrrent password
     */
    public function getCurrentPassword($userID,$accessToken){
    	if ($this->isUserAccessToken($accessToken)) {
	    	$stmt = $this->conn->prepare("SELECT UserID,AccessToken,Password FROM tblUsers  WHERE UserID = ?");
	    	$stmt->bind_param("i",$userID);
	    	if ($stmt->execute()) {
	    		$stmt->store_result();
	    		$stmt->bind_result($userID,$accessToken,$password); 
	    		$stmt->fetch();
	    		$user=array();
	    		$user["UserID"] = $userID;
	    		$user["AccessToken"] = $accessToken;	
	    		$user["Password"] = $password;
	    		$response["common"]["status"] = 0;
	    		$response["common"]["msg"] = "Successful complete";
	    		$response["data"]=$user;
	    		$stmt->close();
	    		
	    	} else {
	    		$response["common"]["status"] = 2;
	    		$response["common"]["msg"] = "DB Error";
	    	}
	    	return $response;
    	}else{
    		$response["common"]["status"] = 101;
    		$response["common"]["msg"] = "Login was failed";
    	}	
    }
    
    //get list notification
    public function getListNotification($userid){ 
    	$user=array();
    	$user["UserID"] = $userid;
    	$user["HaveLiked"] = $this->getCountLike($userid);
    	$user["HavePaired"] =$this->getCountMatched($userid);;
    	$response["common"]["status"] = 0; 
    	$response["common"]["msg"] = "Successful complete";
    	$response["data"]=$user;
    	return $response;
    }
    // get list visitor
    public function getListVisitor($user_id,$limit,$offset,$page){ 
    	//count 
    	$resource="getlistvisitor/";
    	$stmtCount = $this->conn->prepare("SELECT UserName FROM tblUsers INNER JOIN tblVisitors ON tblUsers.UserID=tblVisitors.OtherUserID  WHERE tblVisitors.MyUserID = ?");
    	$stmtCount->bind_param("i",$user_id);
    	$stmtCount->execute();
    	$stmtCount->bind_result($userName);
    	$totalUser=0;
    	while ($stmtCount->fetch()) {
    		++$totalUser;
    	}
    	$totalPage=ceil($totalUser/$limit);
    	$stmtCount->close();
    	
    	$stmt = $this->conn->prepare("SELECT UserID,FirstName,UserName,Email,Gender,LastName,VisitorDate FROM tblUsers INNER JOIN tblVisitors ON tblUsers.UserID=tblVisitors.OtherUserID  WHERE tblVisitors.MyUserID = ?   LIMIT ".$limit." OFFSET ".$offset);
    	$stmt->bind_param("i",$user_id);
    	if ($stmt->execute()) {
    		$stmt->store_result();
    		$stmt->bind_result($userID,$firstName,$userName,$email,$gender,$lastName,$visitorDate);
    		$userList=array();
    		while ($stmt->fetch()) {
    			$user = array();
    			$user["UserID"] = $userID;
    			$user["UserName"] = $userName;
    			$user["VisitorDate"] = $visitorDate;
    			$userLists[]=$user;
    			$userList["UserList"]=$userLists; 
    			//pagination
    			$prePage=$page-1;
    			$nextPage=$page+1;
    			if($page>1 && $page<$totalPage){
    				$userList["paging"]["previousPageUrl"]=URL.$resource.$user_id."?page=".$prePage;
    				$userList["paging"]["currentPageUrl"]=URL.$resource.$user_id."?page=".$page;
    				$userList["paging"]["nextPageUrl"]=URL.$resource.$user_id."?page=".$nextPage;
    			}elseif($page<=1 && $totalPage>1){
    				$userList["paging"]["currentPageUrl"]=URL.$resource.$user_id."?page=".$page;
    				$userList["paging"]["nextPageUrl"]=URL.$resource.$user_id."?page=".$nextPage;
    			}elseif($page>=$totalPage && $totalPage>1){
    				$userList["paging"]["previousPageUrl"]=URL.$resource.$user_id."?page=".$prePage;
    				$userList["paging"]["currentPageUrl"]=URL.$resource.$user_id."?page=".$page;
    			}
    		}
    		$stmt->close();
    	}
    	return $userList;
    }
    
	/**
	 * get list user matched
	 * $user_id int
	 * $option 0:matched, 1: I liked for other $option:  2: Other Liked for me.
	 * $limit t(ype int) is number per page 
	 * $$offset (type int)  position record
	 * $page (type int) is current page
	 */
   
    public function getListUserMatched($user_id,$option,$limit,$offset,$page,$resource) {
    	
    	if($option==MATCHED){ //matched
    		$myLike=1;
    		$mySpecialLike=1;
    		$otherLike=1;
    		$otherSpecialLike=1;
    		$stmtCount=$this->conn->prepare("SELECT UserName FROM tblUsers INNER JOIN tblMatched ON tblUsers.UserID=tblMatched.OtherUserID  WHERE tblMatched.MyUserID = ? AND ((tblMatched.MyLike = ? AND tblMatched.OtherLike = ?) OR (tblMatched.MySpecialLike = ? AND tblMatched.OtherSpecialLike = ?))");
    		$stmtCount->bind_param("iiiii",$user_id,$myLike,$otherLike,$mySpecialLike,$otherSpecialLike);
    	}elseif($option==ILIKED){ // I like
    		$myLike=1;
    		$mySpecialLike=1;
    		$otherLike=0;
    		$otherSpecialLike=0;
    		$stmtCount=$this->conn->prepare("SELECT UserName FROM tblUsers INNER JOIN tblMatched ON tblUsers.UserID=tblMatched.OtherUserID  WHERE tblMatched.MyUserID = ? AND ((tblMatched.MyLike = ? AND tblMatched.OtherLike = ?) OR (tblMatched.MySpecialLike = ? AND tblMatched.OtherSpecialLike = ?)) ");
    		$stmtCount->bind_param("iiiii",$user_id,$myLike,$otherLike,$mySpecialLike,$otherSpecialLike);
    	}else{ //Other like
    		$otherLike=0; 
    		$otherSpecialLike=0;
    		$myLike=1;
    		$mySpecialLike=1;
    		$stmtCount=$this->conn->prepare("SELECT UserName FROM tblUsers INNER JOIN tblMatched ON tblUsers.UserID=tblMatched.OtherUserID  WHERE tblMatched.OtherUserID = ? AND ((tblMatched.MyLike = ? AND tblMatched.OtherLike = ?) OR (tblMatched.MySpecialLike = ? AND tblMatched.OtherSpecialLike = ?)) ");
    		$stmtCount->bind_param("iiiii",$user_id,$myLike,$otherLike,$mySpecialLike,$otherSpecialLike);
    	}
    	
    	$stmtCount->execute();
    	$stmtCount->bind_result($userName);
    	$totalUser=0;
    	while ($stmtCount->fetch()) {
    		++$totalUser;	
    	} 
    	$totalPage=ceil($totalUser/$limit);
    	$stmtCount->close();
    	if($option==MATCHED){
    		$myLike=1;
    		$mySpecialLike=1;
    		$otherLike=1;
    		$otherSpecialLike=1;
    		$stmt = $this->conn->prepare("SELECT OtherUserID,UserName,AccessToken,FirstName,LastName,Gender,Weight,Height,BirthDay,Income,Job,Other,MyLike,OtherLike,MySpecialLike,OtherSpecialLike	b FROM tblUsers INNER JOIN tblMatched ON tblUsers.UserID=tblMatched.OtherUserID  WHERE tblMatched.MyUserID = ? AND ((tblMatched.MyLike = ? AND tblMatched.OtherLike = ?) OR (tblMatched.MySpecialLike = ? AND tblMatched.OtherSpecialLike = ?)) LIMIT ".$limit." OFFSET ".$offset);
			$stmt->bind_param("iiiii",$user_id,$myLike,$otherLike,$mySpecialLike,$otherSpecialLike);
		}elseif($option==ILIKED){ 
			$myLike=1;
			$mySpecialLike=1;
			$otherLike=0;
			$otherSpecialLike=0;
			$stmt = $this->conn->prepare("SELECT OtherUserID,UserName,AccessToken,FirstName,LastName,Gender,Weight,Height,BirthDay,Income,Job,Other,MyLike,OtherLike,MySpecialLike,OtherSpecialLike	b FROM tblUsers INNER JOIN tblMatched ON tblUsers.UserID=tblMatched.OtherUserID  WHERE tblMatched.MyUserID = ? AND ((tblMatched.MyLike = ? AND tblMatched.OtherLike = ?) OR (tblMatched.MySpecialLike = ? AND tblMatched.OtherSpecialLike = ?)) LIMIT ".$limit." OFFSET ".$offset);
			$stmt->bind_param("iiiii",$user_id,$myLike,$otherLike,$mySpecialLike,$otherSpecialLike);
		}else{ 
			$myLike=1;
			$mySpecialLike=1;
			$otherLike=0;
			$otherSpecialLike=0;
			$stmt = $this->conn->prepare("SELECT MyUserID,UserName,AccessToken,FirstName,LastName,Gender,Weight,Height,BirthDay,Income,Job,Other,MyLike,OtherLike,MySpecialLike,OtherSpecialLike	b FROM tblUsers INNER JOIN tblMatched ON tblUsers.UserID=tblMatched.MyUserID  WHERE tblMatched.OtherUserID = ? AND ((tblMatched.MyLike = ? AND tblMatched.OtherLike = ?) OR (tblMatched.MySpecialLike = ? AND tblMatched.OtherSpecialLike = ?))  LIMIT ".$limit." OFFSET ".$offset);
			$stmt->bind_param("iiiii",$user_id,$myLike,$otherLike,$mySpecialLike,$otherSpecialLike);
		}	
    	if ($stmt->execute()) {
    		$stmt->store_result();
    		$stmt->bind_result($userID,$userName,$accessToken,$firstName,$lastName,$gender,$weight,$height,$birthday,$income,$job,$other,$mylike,$otherLike,$mySpecialLike,$otherSpecialLike); 
    		$userList=array();
    		while ($stmt->fetch()) {
    			$user = array();
    			//get first image user 
    			$stmtImage = $this->conn->prepare("SELECT ImageUser FROM tblPhotoUsers  WHERE UserID = ? ORDER BY PhotoID DESC");
    			
    			if ($stmtImage === FALSE){ 
    				die($this->conn->error);
    			} else  {
	    			$stmtImage->bind_param("i",$userID);
			    	if ($stmtImage->execute()) {
			    		$stmtImage->bind_result($imageUser);
			    		$stmtImage->fetch();
			    		$user["ImageUser"]=$imageUser;
			    	}
    			}	
		    	$stmtImage->close();
    			//add array
	    		$user["UserID"] = $userID; 
	    		$user["UserName"] = $userName;
	    		$user["AccessToken"] = $accessToken;
	    		$user["FirstName"] = $firstName;
	    		$user["LastName"] = $lastName;
	    		$user["Gender"] = $gender;
	    		$user["Weight"] = $weight;
	    		$user["Height"] = $height;
	    		$user["BirthDay"] = $birthday;
	    		$user["Income"] = $income;
	    		$user["Job"] = $job;
	    		$user["Other"] = $other;
	    		$user["MyLike"] = $mylike;
	    		$user["OtherLike"] = $otherLike;
	    		$user["MyLikeSpecial"] = $mySpecialLike;
	    		$user["OtherLikeSpecial"] = $otherSpecialLike;
	    		
	    		$userLists[]=$user;
	    		$userList["UserList"]=$userLists;
	    		$prePage=$page-1;
	    		$nextPage=$page+1;
	    		if($page>1 && $page<$totalPage){ 
		    		$userList["paging"]["previousPageUrl"]=URL.$resource.$user_id."?page=".$prePage;
		    		$userList["paging"]["currentPageUrl"]=URL.$resource.$user_id."?page=".$page;
		    		$userList["paging"]["nextPageUrl"]=URL.$resource.$user_id."?page=".$nextPage;
    			}elseif($page<=1 && $totalPage>1){
    				$userList["paging"]["currentPageUrl"]=URL.$resource.$user_id."?page=".$page;
    				$userList["paging"]["nextPageUrl"]=URL.$resource.$user_id."?page=".$nextPage;
    			}elseif($page>=$totalPage && $totalPage>1){
    				$userList["paging"]["previousPageUrl"]=URL.$resource.$user_id."?page=".$prePage;
    				$userList["paging"]["currentPageUrl"]=URL.$resource.$user_id."?page=".$page;
    			}
    		} 
    		$stmt->close();
    		return $userList;
    	} else {
    		return NULL;
    	}
    	
    }
    
    // creating new user if not existed
    public function insertPhoto($accessToken,$userID,$options,$imageSize,$height,$width,$imageUser) {
    	$response = array();
    	// First check if user already existed in db
    	if ($this->isUserAccessToken($accessToken)) {
    		// insert query
    			$stmt = $this->conn->prepare("INSERT INTO tblPhotoUsers( UserID, ImageUser, ImageSize, Width, Height, Options) values( ?, ?, ?, ?, ?, ?)");
				$stmt->bind_param("isiiii", $userID,$imageUser,$imageSize,$width,$height,$options);
	    		$result = $stmt->execute(); 
	    		$stmt->close();
	    		// Check for successful insertion
	    		if ($result) {
	    			// User successfully inserted
	    			$response["common"]["status"] = 0;
	    			$response["common"]["msg"] = "Successful complete";
	    			$response["data"]["ImageUrl"]=$imageUser;
	    			//update users when have image
	    			if($options!=0){ 
	    				$isImage=1;
	    				$stmtImage = $this->conn->prepare("UPDATE tblUsers SET IsImage = ? WHERE UserID = ? ");
	    				$stmtImage->bind_param("ii",$isImage,$userID);
	    				$result = $stmtImage->execute();
	    				$stmtImage->close();
	    			}
	    		} else { 
	    			// Failed to create user
	    			$response["common"]["status"] = 2;
	    			$response["common"]["msg"] = "DB error"; ;
	    		}
    	}else{ 
    		$response["common"]["status"] = 101;
    		$response["common"]["msg"] = "Login was failed";
    	}
    	return $response;	
    	}
    	
    // creating new user if not existed
    public function insertUser($accessToken,$email,$userName,$firstName,$lastName,$birthDay,$fcmRegisteredID,$gender,$facebookID) {
    	$response = array();
    	
    	// First check if user already existed in db
    	if (!$this->isUserExists($email)) { 
    		// insert query
    		$no=$this->getMaxNo()+1; 
    		$stmt = $this->conn->prepare("INSERT INTO tblUsers(AccessToken, UserName, FirstName, LastName, BirthDay, FcmRegisteredID,  Gender, Email,No,FacebookID) values(?, ?, ?, ?, ?, ?, ?, ?,?,?)");
    		$stmt->bind_param("ssssisisis", $accessToken,$userName,$firstName,$lastName,$birthDay,$fcmRegisteredID,$gender,$email,$no,$facebookID);
    		$result = $stmt->execute();
    		$stmt->close();
    		// Check for successful insertion
    		if ($result) { 
    			// User successfully inserted
    			$response["common"]["status"] = 0;
    			$response["common"]["msg"] = "Successful complete";
    			$response["data"]=$this->getUserID($facebookID);
    		} else {
    			// Failed to create user
    			$response["common"]["status"] = 2;
    			$response["common"]["msg"] = "DB error";
    		}
    	} else { 
    		//update db
    		$stmt = $this->conn->prepare("UPDATE tblUsers SET AccessToken = ?, UserName= ?, FirstName= ?, LastName= ?, BirthDay= ?, FcmRegisteredID= ?,  Gender= ?, Email = ? WHERE FacebookID = ? ");
    		$stmt->bind_param("ssssisiss", $accessToken,$userName,$firstName,$lastName,$birthDay,$fcmRegisteredID,$gender,$email,$facebookID);
    		$result = $stmt->execute();
    		$stmt->close();
    		
    		// Check for successful insertion
    		if ($result) {  
    			// User successfully inserted
    			$response["common"]["status"] = 0;
    			$response["common"]["msg"] = "Successful complete";
    			$response["data"]=$this->getUserID($facebookID);
    		} else {
    			// Failed to create user
    			$response["common"]["status"] = 2;
    			$response["common"]["msg"] = "DB error";
    		}
    	}
    
    	return $response;
    }
	
    //insert my friends to server
    public function insertMyFriends($accessToken,$email,$name,$firstName,$lastName,$userID,$gender){
    	if ($this->isUserAccessToken($accessToken)) {
	    	$stmt = $this->conn->prepare("INSERT INTO tblMyFriends(UserID, Name, FirstName, LastName, Gender, Email) values(?, ?, ?, ?, ?, ?)");
	    	$stmt->bind_param("isssis", $userID,$name,$firstName,$lastName,$gender,$email);
	    	$result = $stmt->execute();
	    	$stmt->close(); 
	    	// Check for successful insertion
	    	if ($result) {
	    		// User successfully inserted
	    		$response["common"]["status"] = 0;
	    		$response["common"]["msg"] = "Successful complete";
	    	} else {
	    		// Failed to create user
	    		$response["common"]["status"] = 2;
	    		$response["common"]["msg"] = "DB error";
	    	}
	    }else{
	    		$response["common"]["status"] = 101;
	    		$response["common"]["msg"] = "Login was failed";
	    }	
	    return  $response;
    }
    
    //insert like user
    public function insertSendLike($myUserID,$accessToken,$otherUserID,$myLike,$mySpecialLike){
    	if ($this->isUserAccessToken($accessToken)) {
    		$stmt = $this->conn->prepare("INSERT INTO tblMatched(MyUserID, OtherUserID, MyLike, MySpecialLike) values(?, ?, ?,?)");
    		$stmt->bind_param("iiii", $myUserID,$otherUserID,$myLike,$mySpecialLike);
    		$result = $stmt->execute();
    		$stmt->close();
    		// Check for successful insertion
    		if ($result) {
    			// User successfully inserted
    			$response["common"]["status"] = 0;
    			$response["common"]["msg"] = "Successful complete";
    		} else {
    			// Failed to create user
    			$response["common"]["status"] = 2;
    			$response["common"]["msg"] = "DB error";
    		}
    	}else{
    		$response["common"]["status"] = 101;
    		$response["common"]["msg"] = "Login was failed";
    	}
    	
    	return $response;
    }
    
    // updating user
    public function updateUsers($facebookID,$accessToken) { 
    	$accessNewToken="";
    	$response = array();
    	if ($this->isUserAccessToken($accessToken)) {
	    	$stmt = $this->conn->prepare("UPDATE tblUsers SET AccessToken = ? WHERE  FacebookID= ? ");
	    	$stmt->bind_param("ss", $accessNewToken,$facebookID);
	    
	    	if ($stmt->execute()) {
	    		// User successfully updated
	    		$response["common"]["status"] = 0;
	    		$response["common"]["message"] = 'Successful complete';
	    	} else {
	    		// Failed to update user
	    		$response["common"]["status"] = 2;
	    		$response["common"]["message"] = "DB error";
	    		$stmt->error;
	    	}
	    	$stmt->close();
    	}else{
    		$response["common"]["status"] = 101;
    		$response["common"]["message"] = "Login was failed";
    	}	
    
    	return $response;
    }
    
    //update user profile 
    public function updateUserProfile($userID,$accessToken,$userName
    		,$firstName,$lastName,$gender,$email
    		,$birthDay,$changedDate,$height,$weight,$skills,$hobby,$address
    		,$homeTown,$language,$bloodType,$job,$income,$literacy,$genitive
    		,$extrovert,$attraction,$drinking,$smoking,$siblings,$whoLivesWith
    		,$holiday,$whenMarriage,$requirement,$maritalStatus,$havingChildren
    		,$criteriaConsidered,$wantAppointments,$costForFirstAppointments,$other){
    			$response = array();
    			$other=($other!="") ? $other : NULL;
    			$height=($height!="") ? $height : NULL;
    			$weight=($weight!="") ? $weight : NULL;
    			$skills=($skills!="") ? $skills : NULL;
    			$hobby=($hobby!="") ? $hobby : NULL;
    			$address=($address!="") ? $address : NULL;
    			$homeTown=($homeTown!="") ? $homeTown : NULL;
    			$language=($language!="") ? $language : NULL;
    			$bloodType=($bloodType!="") ? $bloodType : NULL;
    			$job=($job!="") ? $job : NULL;
    			$income=($income!="") ? $income : NULL;
    			$literacy=($literacy!="") ? $literacy : NULL;
    			$genitive=($genitive!="") ? $genitive : NULL;
    			$extrovert=($extrovert!="") ? $extrovert : NULL;
    			$attraction=($attraction!="") ? $attraction : NULL;
    			$drinking=($drinking!="") ? $drinking : NULL;
    			$smoking=($smoking!="") ? $smoking : NULL;
    			$siblings=($siblings!="") ? $siblings : NULL;
    			$whoLivesWith=($whoLivesWith!="") ? $whoLivesWith : NULL;
    			$holiday=($holiday!="") ? $holiday : NULL;
    			$whenMarriage=($whenMarriage!="") ? $whenMarriage : NULL;
    			$requirement=($requirement!="") ? $requirement : NULL;
    			$maritalStatus=($maritalStatus!="") ? $maritalStatus : NULL;
    			$criteriaConsidered=($criteriaConsidered!="") ? $criteriaConsidered : NULL;
    			$wantAppointments=($wantAppointments!="") ? $wantAppointments : NULL;
    			$costForFirstAppointments=($costForFirstAppointments!="") ? $costForFirstAppointments : NULL;
    			//check accesstoken
    			if ($this->isUserAccessToken($accessToken)) {
    				$stmt = $this->conn->prepare("UPDATE tblUsers SET UserName = ?, FirstName = ?, LastName = ?, Gender = ?,Email = ?
    													,BirthDay = ?,ChangedDate = ?, Height = ?,Weight = ?,Skills = ?,Hobby = ?, Address = ?
    													,HomeTown = ?,Language = ?,BloodType = ?, Job = ?,Income = ?,Literacy = ?,Genitive = ?
    													,Extrovert = ?,Attraction = ?, Drinking = ?,Smoking = ?,Siblings = ?,WhoLivesWith = ?
    													,Holiday = ?,WhenMarriage = ?, Requirement = ?,MaritalStatus = ?,HavingChildren = ?
    													,CriteriaConsidered = ?,WantAppointments = ?, CostForFirstAppointments = ?, Other= ?
    													WHERE UserID = ?");
    				$stmt->bind_param("sssisssiissssssssssssssssssssissssi"
    								, $userName,$firstName,$lastName,$gender,$email
						    		,$birthDay,$changedDate,$height,$weight,$skills,$hobby,$address
						    		,$homeTown,$language,$bloodType,$job,$income,$literacy,$genitive
						    		,$extrovert,$attraction,$drinking,$smoking,$siblings,$whoLivesWith
						    		,$holiday,$whenMarriage,$requirement,$maritalStatus,$havingChildren
						    		,$criteriaConsidered,$wantAppointments,$costForFirstAppointments,$other,$userID);
    				 
    				if ($stmt->execute()) {
    					// User successfully updated
    					$response["common"]["status"] = 0;
    					$response["common"]["message"] = 'Successful complete';
    				} else {
    					// Failed to update user
    					$response["common"]["status"] = 2;
    					$response["common"]["message"] = "DB error";
    					$stmt->error;
    				}
    				$stmt->close();
    			}else{
    				$response["common"]["status"] = 101;
    				$response["common"]["message"] = "Login was failed";
    			}
    			
    			return $response;
    }
    
    // get user information
    public function getDetailUser($accessToken,$myUserID,$otherUserID) {
    	$stmt = $this->conn->prepare("SELECT * FROM tblUsers  WHERE UserID = ?");
        $stmt->bind_param("i",$otherUserID);
        if ($stmt->execute()) {
             $users = $stmt->get_result()->fetch_assoc(); 
         /*  // $stmt->bind_result($user_id);
            $stmt->fetch(); */
            $user = array();
            $user["UserID"] = $users["UserID"]; 
            $user["AccessToken"] = $users["AccessToken"]; 
            $user["UserName"] = $users["UserName"];
            $user["FirstName"] = $users["FirstName"];
            $user["LastName"] = $users["LastName"];
            $user["Gender"] = $users["Gender"];
            $user["Email"] = $users["Email"];
            $user["BirthDay"] = $users["BirthDay"];
            $user["Skills"] = $users["Skills"];
            $user["Hobby"] = $users["Hobby"];
            $user["Weight"] = $users["Weight"];
            $user["Height"] = $users["Height"];
            $user["No"] = $users["No"];
            $user["Address"] = $users["Address"];
            $user["HomeTown"] = $users["HomeTown"];
            $user["Language"] = $users["Language"];
            $user["BloodType"] = $users["BloodType"];
            $user["Job"] = $users["Job"];
            $user["Income"] = $users["Income"];
            $user["Literacy"] = $users["Literacy"];
            $user["Genitive"] = $users["Genitive"];
            $user["Extrovert"] = $users["Extrovert"];
            $user["Attraction"] = $users["Attraction"];
            $user["Drinking"] = $users["Drinking"];
            $user["Smoking"] = $users["Smoking"];
            $user["Siblings"] = $users["Siblings"];
            $user["WhoLivesWith"] = $users["WhoLivesWith"];
            $user["Holiday"] = $users["Holiday"];
            $user["WhenMarriage"] = $users["WhenMarriage"];
            $user["Requirement"] = $users["Requirement"];
            $user["MaritalStatus"] = $users["MaritalStatus"];
            $user["HavingChildren"] = $users["HavingChildren"];
            $user["CriteriaConsidered"] = $users["CriteriaConsidered"];
            $user["WantAppointments"] = $users["WantAppointments"];
            $user["CostForFirstAppointments"] = $users["CostForFirstAppointments"];
            $user["Other"] = $users["Other"];
            $stmt->close();
            if ($this->isUserAccessToken($accessToken)) {
	            $visitors=$users["Visitors"]+1; 
	            $stmtUpdateVisitor = $this->conn->prepare("INSERT INTO tblVisitors(OtherUserID, MyUserID) values( ?, ?)");
    			$stmtUpdateVisitor->bind_param("ii", $otherUserID,$myUserID);
    			if ($stmtUpdateVisitor->execute()) {
	            	return $user;
	            }else{
	            	return NULL;
	            }
	            $stmtUpdateVisitor->close();
            }else{
            	$response["common"]["status"] = 101;
            	$response["common"]["message"] = "Login was not successed";
            }    
            
        } else {
            return NULL;
        }
    }
    
    // get list image
    public function getListImageUser($user_id) { 
    	$listImages=array();
    	$stmt = $this->conn->prepare("SELECT * FROM tblPhotoUsers  WHERE UserID = ?");
    	$stmt->bind_param("i",$user_id);
    	if ($stmt->execute()) {
    		$result = $stmt->get_result();
	    		while ($listImage = $result->fetch_assoc()) {
	    			$tmp = array();
	    			$tmp["ImageUser"] = $listImage['ImageUser'];
	    			array_push($listImages, $tmp);
	    		}
	    		if(sizeof($listImages)==0) $listImages=null;
    		$stmt->close();
    		return $listImages;
    	} else {
    		return NULL;
    	}
    }
    
    // updating user when leave app
    public function updateLeaveApp($userID, $accessToken,$status) {
        $response = array();
        if ($this->isUserAccessToken($accessToken)) {
	        $stmt = $this->conn->prepare("UPDATE tblUsers SET Status = ? WHERE UserID = ?");
	        $stmt->bind_param("si", $status, $userID);
	
	        if ($stmt->execute()) {
	            // User successfully updated
	           	$response["common"]["status"] = 0;
        		$response["common"]["message"] = "Successful complete";
        		$response["data"]["UserID"] =$userID;
        		$response["data"]["Status"] =$status;
	        } else {
	            // Failed to update user
	            $response["common"]["status"] = 2;
        		$response["common"]["message"] = "DB error";
	        }
	        $stmt->close();
        }else{
        	$response["common"]["status"] = 101;
        	$response["common"]["message"] = "Login was not successed";
        }    

        return $response;
    }

    /**
     * Checking for duplicate user by email address
     * @param String $email email to check in db
     * @return boolean
     */
    public function isUserExists($email) {
        $stmt = $this->conn->prepare("SELECT Email from tblUsers WHERE Email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->store_result(); 
        $num_rows = $stmt->num_rows; 
        $stmt->close();
        return $num_rows > 0;
    }

    /**
     * get count Like sent for user
     *
     */
    private function getCountLike($userID) {
    	$myLike=1;
    	$mySpecialLike=1;
    	$otherLike=0;
    	$otherSpecialLike=0;
    	$stmt = $this->conn->prepare("SELECT count(MyUserID) as numberUser FROM tblUsers INNER JOIN tblMatched ON tblUsers.UserID=tblMatched.MyUserID WHERE tblMatched.OtherUserID = ? AND ((tblMatched.MyLike = ? AND tblMatched.OtherLike = ?) OR (tblMatched.MySpecialLike = ? AND tblMatched.OtherSpecialLike = ?)) ");
    	$stmt->bind_param("iiiii",$userID,$myLike,$otherLike,$mySpecialLike,$otherSpecialLike);
    	$stmt->execute();
    	$stmt->bind_result($numberUser);
    	$stmt->fetch();
    	$number=$numberUser; 
    	$stmt->close();
    	return $number;
    }
    
    /**
     * get count matched
     *
     */
    private function getCountMatched($userID) {
    	$myLike=1;
    	$mySpecialLike=1;
    	$otherLike=1;
    	$otherSpecialLike=1;
    	$stmt = $this->conn->prepare("SELECT count(UserID) as numberUser FROM tblUsers INNER JOIN tblMatched ON tblUsers.UserID=tblMatched.MyUserID WHERE tblMatched.OtherUserID = ? AND ((tblMatched.MyLike = ? AND tblMatched.OtherLike = ?) OR (tblMatched.MySpecialLike = ? AND tblMatched.OtherSpecialLike = ?))");
    	$stmt->bind_param("iiiii",$userID,$myLike,$otherLike,$mySpecialLike,$otherSpecialLike);
    	$stmt->execute();
    	$stmt->bind_result($numberUser);
    	$stmt->fetch();
    	$number=$numberUser; 
    	$stmt->close();
    	return $number;
    }
    
    /**
     * get UserID
     *
     */
    private function getUserID($facebookID) {
    	$stmt = $this->conn->prepare("SELECT UserID from tblUsers WHERE FacebookID = ?");
    	$stmt->bind_param("s", $facebookID);
    	if ($stmt->execute()) {
            // $user = $stmt->get_result()->fetch_assoc();
            $stmt->bind_result($user_id);
            $stmt->fetch();
            $user = array();
            $user["UserID"] = $user_id;
    	}    
    	$stmt->close();
    	return $user;
    }
    
    /**
     * get max no
     * 
     */
    private function getMaxNo() {
    	$stmt = $this->conn->prepare("SELECT MAX(No) as No from tblUsers");
    	$stmt->execute();
    	$stmt->bind_result($no);
            $stmt->fetch();
            $number=$no;
            $stmt->close();
            return $number;
    }
    
    /**
     * Checking for duplicate user by access token address
     * @param String $AccessToken email to check in db
     * @return boolean
     */
    private function isUserAccessToken($AccessToken) {
    	$stmt = $this->conn->prepare("SELECT UserID from tblUsers WHERE AccessToken = ?");
    	$stmt->bind_param("s", $AccessToken);
    	$stmt->execute();
    	$stmt->store_result();
    	$num_rows = $stmt->num_rows;
    	$stmt->close();
    	return $num_rows > 0;
    }
    
    /**
     * Checking for duplicate user by access token address
     * @param String UserID to check in db
     * @return boolean
     */
    private function isUserID($userID) {
    	$stmt = $this->conn->prepare("SELECT UserID from tblUsers WHERE UserID = ?");
    	$stmt->bind_param("i", $userID);
    	$stmt->execute();
    	$stmt->store_result();
    	$num_rows = $stmt->num_rows;
    	$stmt->close();
    	return $num_rows > 0;
    }
    /**
     * Fetching user by email
     * @param String $email User email id       
     */
    public function getUserByEmail($email) {
        $stmt = $this->conn->prepare("SELECT user_id, name, email, created_at FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        if ($stmt->execute()) {
            // $user = $stmt->get_result()->fetch_assoc();
            $stmt->bind_result($user_id, $name, $email, $created_at);
            $stmt->fetch();
            $user = array();
            $user["user_id"] = $user_id;
            $user["name"] = $name;
            $user["email"] = $email;
            $user["created_at"] = $created_at;
            $stmt->close();
            return $user;
        } else {
            return NULL;
        }
    }

}

?>
