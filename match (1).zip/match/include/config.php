<?php
/**
 * Database configuration
 */
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');
define('DB_HOST', 'localhost');
define('DB_NAME', 'matching');

define("GOOGLE_API_KEY", "AIzaSyDKk_ew7Vi4FZnMzu6GCY5nLb4xZG8muvI");
define("URL", "http://192.168.1.33/match/v1/");
define("MATCHED", "0");
define("ILIKED", "1");
define("OTHERLIKED", "2");

// push notification flags
define('PUSH_FLAG_CHATROOM', 1);
define('PUSH_FLAG_USER', 2);

?>
