<?php
/**
 * @author Ravi Tamada
 * @link URL Tutorial link
 */
class GCM {

    // constructor
    function __construct() {
        
    }

    // sending push message to single user by gcm registration id
    public function send($to, $message) {
        $fields = array(
            'to' => $to,
            'data' => $message,
        );
        return $this->sendPushNotification($fields);
    }
	
	public function sendMessage($data){ 
		//return $this->sendFCMNotify($data);
		return $this->send_gcm_notify("",$data['message'],"","");
	}
    // Sending message to a topic by topic id
    public function sendToTopic($to, $message) {
        $fields = array(
            'to' => '/topics/' . $to,
            'data' => $message,
        );
        //return $this->sendPushNotification($fields);
        return $this->send_gcm_notify("cfK23SLP4jo:APA91bHk1I3-Rem2oLsZ4_osrCPz2tXujziLJXZiPehla2F1GSsiutAv47ZtDuqhOz5JqYfcFqnZNkwSIdUgRx9k5yqzHGzZ6_e3oWL8cPAmai3Z5dTXQSv_6MdkBGT0WRWL2pAlqYID",$message,"","");
        //return $this->send_gcm_notify("ca4r9ZNyHjw:APA91bFlRK4El0WoDRO52i_UO82mwaW-YvK_PGWO9EZqMeapG7XGi2nI4SAdmmuC7sXt3tiF6-5b_YfxBuxXTdh2unuObKZF1tDtdiy20DP3dYyBkRAGDBETX_kEeqkhzOthB4T9F5uY",$message,"","");
        //return $this->send_gcm_notify("c4GmcLjwGMA:APA91bEC9iIW_xV-ZLgoS1mcHUtED23Rp5NFStTSpya-nEqRruprvph6HQKmLeBX4dh5eg82EC9vy1rQdqcw8BYrpBCMXZM4oRE9ddLaAgugYsSbZNWOjmswKO5uPlivZ7m0sS45aTQf",$message,"","");
    	
    }

    // sending push message to multiple users by gcm registration ids
    public function sendMultiple($registration_ids, $message) {
        $fields = array(
            'registration_ids' => $registration_ids,
            'data' => $message,
        );

        return $this->sendPushNotification($fields);
    }

    // function makes curl request to gcm servers
    private function sendPushNotification($fields) {

        // include config
        include_once __DIR__ . '/../../include/config.php';

        // Set POST variables
        $url = 'https://gcm-http.googleapis.com/gcm/send';

        $headers = array(
            'Authorization: key=' . GOOGLE_API_KEY,
            'Content-Type: application/json'
        );
        // Open connection
        $ch = curl_init();

        // Set the url, number of POST vars, POST data
        curl_setopt($ch, CURLOPT_URL, $url);

        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        // Disabling SSL Certificate support temporarly
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));

        // Execute post
        $result = curl_exec($ch);
        if ($result === FALSE) {
            die('Curl failed: ' . curl_error($ch));
        }

        // Close connection
        curl_close($ch);

        return $result;
    }
	
	//Customer
	function send_gcm_notify($reg_id, $message, $img_url, $tag) {
 		//if (!empty($_POST)) {
 			$response = array("error" => FALSE);
 			
 			//define("GOOGLE_API_KEY", "AIzaSyDQvSsAkIGSMSwIWVfwO63SMFAVpXI-YMw");
 			//define("GOOGLE_GCM_URL", "https://fcm.googleapis.com/fcm/send");
 			$api_key = "AIzaSyDQvSsAkIGSMSwIWVfwO63SMFAVpXI-YMw";
 			$url_server = "https://fcm.googleapis.com/fcm/send";
 			$registration_ids=array('c4GmcLjwGMA:APA91bEC9iIW_xV-ZLgoS1mcHUtED23Rp5NFStTSpya-nEqRruprvph6HQKmLeBX4dh5eg82EC9vy1rQdqcw8BYrpBCMXZM4oRE9ddLaAgugYsSbZNWOjmswKO5uPlivZ7m0sS45aTQf','cfK23SLP4jo:APA91bHk1I3-Rem2oLsZ4_osrCPz2tXujziLJXZiPehla2F1GSsiutAv47ZtDuqhOz5JqYfcFqnZNkwSIdUgRx9k5yqzHGzZ6_e3oWL8cPAmai3Z5dTXQSv_6MdkBGT0WRWL2pAlqYID','ca4r9ZNyHjw:APA91bFlRK4El0WoDRO52i_UO82mwaW-YvK_PGWO9EZqMeapG7XGi2nI4SAdmmuC7sXt3tiF6-5b_YfxBuxXTdh2unuObKZF1tDtdiy20DP3dYyBkRAGDBETX_kEeqkhzOthB4T9F5uY');
 			$fields = array(
 				'registration_ids' => $registration_ids,
 				//'to' =>$reg_id ,
 				'priority' => "high",
 				'notification' => array( "title" => "Android Learning", "body" => $message, "tag" => $tag ),
 				'data' => array("message" =>$message, "image"=> $img_url),
 			);
 
 			$headers = array("GOOGLE_GCM_URL",
 					'Content-Type: application/json',
 					'Authorization: key=' . $api_key 
 					);
			
 			
 			$ch = curl_init();
 			curl_setopt($ch, CURLOPT_URL, $url_server);
 			curl_setopt($ch, CURLOPT_POST, true);
 			curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
 			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
 			curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
 			curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
 			$result = curl_exec($ch); 
 			if ($result === FALSE) {
 				die('Problem occurred: ' . curl_error($ch));
 			}
 
 			curl_close($ch);
			return $result;
 		//}
 	/*
 		$reg_id = $_POST['fcm_id'];
 		$msg = $_POST['msg'];
 		$img_url = '';
 		$tag = 'text';
 		if ($_FILES['image']['name'] != '') {
 
			$tag = 'image';
 			$target_file = $target_path . basename($_FILES['image']['name']);
 			$img_url = 'http://192.168.1.33/fcm_server/'.$target_file;
 			try {
 			// Throws exception incase file is not being moved
 			if (!move_uploaded_file($_FILES['image']['tmp_name'], $target_file)) {
 				// make error flag true
 				echo json_encode(array('status'=>'fail', 'message'=>'could not move file'));
 			}
 
 			// File successfully uploaded
 				echo json_encode(array('status'=>'success', 'message'=> $img_url));
 			} catch (Exception $e) {
 			// Exception occurred. Make error flag true
 				echo json_encode(array('status'=>'fail', 'message'=>$e->getMessage()));
 			}
		}
		*/
	}
	
	function sendFCMNotify($dataPush) {
			$img_url="";
			$message=$dataPush['message'];
 		//if (!empty($_POST)) {
 			$response = array("error" => FALSE);
 			
 			//define("GOOGLE_API_KEY", "AIzaSyDQvSsAkIGSMSwIWVfwO63SMFAVpXI-YMw");
 			//define("GOOGLE_GCM_URL", "https://fcm.googleapis.com/fcm/send");
 			$api_key = "AIzaSyDQvSsAkIGSMSwIWVfwO63SMFAVpXI-YMw";
 			$url_server = "https://fcm.googleapis.com/fcm/send";
 			$registration_ids=array($dataPush['fromUserRegisteredID'],$dataPush['toUserRegisteredID']);
 			$fields = array(
 				'registration_ids' => $registration_ids,
 				//'to' =>$reg_id ,
 				'priority' => "high",
 				'notification' => array( "title" => "Android Learning", "body" => $message, "tag" => $tag ),
 				'data' => array("message" =>$message, "image"=> $img_url),
 			);
 
 			$headers = array("GOOGLE_GCM_URL",
 					'Content-Type: application/json',
 					'Authorization: key=' . $api_key 
 					);
			
 			
 			$ch = curl_init();
 			curl_setopt($ch, CURLOPT_URL, $url_server);
 			curl_setopt($ch, CURLOPT_POST, true);
 			curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
 			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
 			curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
 			curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
 			$result = curl_exec($ch); 
 			if ($result === FALSE) {
 				die('Problem occurred: ' . curl_error($ch));
 			}
 
 			curl_close($ch);
			return $result; 
 		//}
 		}
	
}

?>